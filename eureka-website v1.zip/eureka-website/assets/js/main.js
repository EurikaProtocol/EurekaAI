document.querySelectorAll('button').forEach(b=>b.addEventListener('mouseenter',()=>b.style.transform='scale(1.03)'));console.log('EUREKA READY');
